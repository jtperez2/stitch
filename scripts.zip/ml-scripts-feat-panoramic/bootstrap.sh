#!/bin/sh
export FLASK_APP=./ml-scripts/index.py

# Asegúrate de que el entorno virtual esté activado
pyenv activate ml-scripts

flask --debug run -h 0.0.0.0
