# ml-scripts
different scripts and snippets useful for processes of the Discovery Project

## Installation instructions

* Install pipenv
* In the project directory run `pipenv shell` and `pipenv install`
* Create *.env* file to set enviroment variables
* Export *Postman* collection

## Bootstrapping instructions

* In the project directory run `./bootstrap.sh`
