from flask import jsonify

class ResponsesFormat(object):
    def __init__(self):
        print('--init helper--')

    def __repr__(self):
        return '<ImageProcessor()>'.format(self=self)

    @staticmethod
    def json_template(status_code, body):
        return jsonify({
            'statusCode': status_code,
            'body': body
        })
