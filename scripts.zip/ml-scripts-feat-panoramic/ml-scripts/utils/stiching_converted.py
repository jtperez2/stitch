# Import packages
import os
import cv2
import shutil
import numpy as np
import gdown
import requests
from stitching import Stitcher

class StichingConverter(object):
    def __init__(self):
        print('--init helper--')

    def __repr__(self):
        return '<StichingConverter()>'.format(self=self)
    
    def DeleteFolder(folder_path):
        for file in os.listdir(folder_path):
            full_path = os.path.join(folder_path, file)
            try:
                if os.path.isfile(full_path) or os.path.islink(full_path):
                    os.unlink(full_path)
                elif os.path.isdir(full_path):
                    shutil.rmtree(full_path)
            except Exception as e:
                print(f"No se pudo eliminar {full_path}. Razón: {e}")

    def ConvertVideoToImages(app, input_video_url, format='jpg'):

        input_path_folder = './ml-scripts/files/inputs/video/'
        output_path_folder = './ml-scripts/files/outputs/pictures/'
        video_name = 'input.mp4'
        reduction_factor = 10
        image_name_count = 0

        # Vacia carpetas
        StichingConverter.DeleteFolder(input_path_folder)
        StichingConverter.DeleteFolder(output_path_folder)

        # Descarga el vieo desde una URL
        gdown.download(input_video_url, input_path_folder + video_name, quiet=False)

        # Carga video a OpenCV
        cap = cv2.VideoCapture(input_path_folder + video_name)

        # Verifica si el video se abrió correctamente
        if not cap.isOpened():
            app.logger.info("Error al abrir el video.")
            return

        # Crea la carpeta de salida si no existe
        if not os.path.exists(output_path_folder):
            os.makedirs(output_path_folder)

        # Obtiene la tasa de frames por segundo (fps) del video
        fps = cap.get(cv2.CAP_PROP_FPS)

        # Inicializa el contador de frames
        frame_count = 0

        while True:
            # Lee el siguiente frame del video
            ret, frame = cap.read()

            # Verifica si se llegó al final del video
            if not ret:
                break

            if frame_count % reduction_factor == 0:
                file_name = f"{image_name_count:04d}.{format}"
                out_path = os.path.join(output_path_folder, file_name)
                cv2.imwrite(out_path, frame)
                image_name_count += 1

            # Incrementa el contador de frames
            frame_count += 1

        # Libera los recursos
        cap.release()

        app.logger.info(f"Se han generado {image_name_count} imágenes en {output_path_folder}.")

    def CreateStiching(app, output_name, crop, detector="brisk"):
        app.logger.info("ADUKEN")
        app.logger.info(detector)
        settings = {"detector": detector, "confidence_threshold": 0.8, "crop": crop}
        stitcher = Stitcher(**settings)
        input_pictures_path = "./ml-scripts/files/outputs/pictures/????.jpg"
        result_path = "./ml-scripts/files/outputs/result/" + output_name

        try:
            panorama = stitcher.stitch([input_pictures_path])

            if panorama is not None:
                cv2.imwrite(result_path, panorama)
                app.logger.info("Imagen panorámica guardada")
                requests.post('https://hooks.slack.com/services/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', json={'text': "Imagen panoramica creada!!", 'username': 'CASCANA'})
            else:
                app.logger.info("No se pudo generar la imagen panorámica.")

        except Exception as e:
            app.logger.info(f"Error durante la costura de las imágenes: {str(e)}")