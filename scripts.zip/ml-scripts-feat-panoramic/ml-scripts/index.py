from flask import Flask, request, send_from_directory
from .utils.responses_format import ResponsesFormat
from .utils.stiching_converted import StichingConverter
import logging

app = Flask(__name__)
logging.basicConfig(filename='app.log', level=logging.DEBUG)


@app.route('/api/run-stiching', methods=['POST'])
def run_process_gapp():
    # get arguments
    try:
        output_name = request.get_json()["outputName"]
        video_url = request.get_json()["videoUrl"]
        crop = request.get_json()["crop"]
    except:
        return ResponsesFormat.json_template(500, {'message': 'arguments are missing or invalid'})
    
    # StichingConverter.ConvertVideoToImages(app, video_url)
    StichingConverter.CreateStiching(app, output_name, crop)

    return ResponsesFormat.json_template(201, {'result': "http://" + request.host + "/api/downloads/" + output_name })

@app.route('/api/downloads/<filename>')
def downloads(filename):
    return send_from_directory("./files/outputs/result", filename, as_attachment=True)